<?php

namespace Tests\Models;

use Helium\LaravelHelpers\Traits\DefaultOrdering;
use Tests\Models\Base\TestModel;

class DefaultOrderingModel extends TestModel
{
	use DefaultOrdering;
}