<?php

namespace Tests\Models\Base;

trait SetupGeneratesPrimaryKey
{
	public $primaryKeyPrefix = 'GPK';
}